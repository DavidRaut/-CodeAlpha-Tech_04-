import os
import shutil
import pandas as pd
import logging
import psutil
import subprocess
import platform

# Configure logging
logging.basicConfig(filename="task_automation.log", level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s")


# 1. File Organization
def organize_files(directory):
    """
    Organizes files in the specified directory into subfolders based on their extensions.
    """
    try:
        if not os.path.exists(directory):
            raise FileNotFoundError(f"The directory '{directory}' does not exist.")

        for file in os.listdir(directory):
            file_path = os.path.join(directory, file)
            if os.path.isfile(file_path):
                extension = file.split('.')[-1] if '.' in file else "others"
                extension_folder = os.path.join(directory, extension.upper())

                os.makedirs(extension_folder, exist_ok=True)
                shutil.move(file_path, os.path.join(extension_folder, file))

        logging.info(f"Files in '{directory}' have been organized by file type.")
        print(f"Files in '{directory}' have been organized successfully.")
    except Exception as e:
        logging.error(f"Error organizing files: {e}")
        print(f"Error: {e}")


# 2. Data Cleaning
def clean_data(file_path):
    """
    Cleans a CSV file by removing duplicates and filling missing values.
    """
    try:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"The file '{file_path}' does not exist.")

        df = pd.read_csv(file_path)

        # Drop duplicate rows
        df.drop_duplicates(inplace=True)

        # Fill missing values with appropriate defaults
        df.fillna("Unknown", inplace=True)

        # Save the cleaned data back to the file
        df.to_csv(file_path, index=False)

        logging.info(f"Data in '{file_path}' has been cleaned successfully.")
        print(f"Data in '{file_path}' has been cleaned successfully.")
    except Exception as e:
        logging.error(f"Error cleaning data: {e}")
        print(f"Error: {e}")


# 3. System Maintenance
def system_maintenance():
    """
    Performs basic system maintenance tasks like clearing temp files and checking system usage.
    """
    try:
        # Clear temporary files
        temp_dir = os.getenv('TEMP')
        if temp_dir and os.path.exists(temp_dir):
            for temp_file in os.listdir(temp_dir):
                temp_file_path = os.path.join(temp_dir, temp_file)
                try:
                    if os.path.isfile(temp_file_path):
                        os.remove(temp_file_path)
                    elif os.path.isdir(temp_file_path):
                        shutil.rmtree(temp_file_path)
                except Exception as e:
                    logging.warning(f"Unable to delete {temp_file}: {e}")

        # Log system information
        cpu_usage = psutil.cpu_percent(interval=1)
        memory_info = psutil.virtual_memory()
        disk_usage = psutil.disk_usage('/')

        system_info = f"""
        System Maintenance Report:
        - CPU Usage: {cpu_usage}%
        - Memory Usage: {memory_info.percent}%
        - Disk Usage: {disk_usage.percent}%
        """
        logging.info(system_info)
        print(system_info)

        # Optional: Perform disk cleanup (Windows example)
        if platform.system() == "Windows":
            subprocess.run("cleanmgr /sagerun:1", shell=True)

        logging.info("System maintenance completed successfully.")
        print("System maintenance tasks completed.")
    except Exception as e:
        logging.error(f"Error performing system maintenance: {e}")
        print(f"Error: {e}")


# Main Function
if __name__ == "__main__":
    # Example usage
    print("Task Automation Script")
    print("1. Organize Files")
    print("2. Clean Data")
    print("3. Perform System Maintenance")
    choice = input("Choose a task (1, 2, or 3): ")

    if choice == "1":
        directory = input("Enter the directory to organize: ")
        organize_files(directory)
    elif choice == "2":
        file_path = input("Enter the CSV file path to clean: ")
        clean_data(file_path)
    elif choice == "3":
        system_maintenance()
    else:
        print("Invalid choice. Exiting.")
